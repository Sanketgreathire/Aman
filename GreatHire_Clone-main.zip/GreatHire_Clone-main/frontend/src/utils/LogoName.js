export const firstName = "Great";
export const secondName = "Hire";