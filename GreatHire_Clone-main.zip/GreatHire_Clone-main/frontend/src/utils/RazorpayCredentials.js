// Razorpay credentials
export const razorpay_key_id = import.meta.env.VITE_RAZORPAY_KEY_ID;
export const razorpay_key_secret = import.meta.env.VITE_RAZORPAY_KEY_SECRET;