// google auth credeentials
export const google_project_id = import.meta.env.VITE_GOOGLE_PROJECT_ID
export const google_client_id = import.meta.env.VITE_GOOGLE_CLIENT_ID
export const google_client_secret = import.meta.env.VITE_GOOGLE_CLIENT_SECRET